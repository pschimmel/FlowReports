﻿namespace FlowReports.Model
{
  public enum InsertLocation
  {
    Before, After
  }
}