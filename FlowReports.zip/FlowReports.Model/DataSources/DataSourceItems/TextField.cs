﻿namespace FlowReports.Model.DataSources.DataSourceItems
{
  public class TextField : DataSourceItem
  {
  }
}
