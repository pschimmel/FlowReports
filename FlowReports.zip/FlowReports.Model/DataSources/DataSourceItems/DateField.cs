﻿namespace FlowReports.Model.DataSources.DataSourceItems
{
  public class DateField : DataSourceItem
  {
  }
}
