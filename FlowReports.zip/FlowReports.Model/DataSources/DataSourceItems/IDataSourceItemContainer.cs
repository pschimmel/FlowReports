﻿namespace FlowReports.Model.DataSources.DataSourceItems
{
  public interface IDataSourceItemContainer : IList<IDataSourceItem>, IDataSourceItem
  {
  }
}