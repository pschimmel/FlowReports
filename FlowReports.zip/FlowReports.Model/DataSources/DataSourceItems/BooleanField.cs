﻿namespace FlowReports.Model.DataSources.DataSourceItems
{
  public class BooleanField : DataSourceItem
  {
  }
}
