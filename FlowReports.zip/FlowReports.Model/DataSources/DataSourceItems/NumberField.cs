﻿namespace FlowReports.Model.DataSources.DataSourceItems
{
  public class NumberField : DataSourceItem
  {
  }
}
