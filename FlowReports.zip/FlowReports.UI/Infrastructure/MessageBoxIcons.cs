﻿namespace FlowReports.UI.Infrastructure
{
  internal enum MessageBoxIcons
  {
    Information,
    Warning,
    Error,
    Question
  }
}
