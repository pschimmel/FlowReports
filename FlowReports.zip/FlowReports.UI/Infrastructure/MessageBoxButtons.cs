﻿namespace FlowReports.UI.Infrastructure
{
  internal enum MessageBoxButtons
  {
    OK,
    OKCancel,
    YesNo,
    YesNoCancel
  }
}
