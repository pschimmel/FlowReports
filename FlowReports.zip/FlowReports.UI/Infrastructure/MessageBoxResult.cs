﻿namespace FlowReports.UI.Infrastructure
{
  internal enum MessageBoxResult
  { 
    Yes,
    No,
    Cancel
  }
}
