﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Input;
using ES.Tools.Core.MVVM;
using FlowReports.Model.Events;
using FlowReports.Model.ReportItems;

namespace FlowReports.UI.ViewModel
{
  public class ReportBandViewModel : BandContainerViewModel
  {
    #region Event

    public event EventHandler ItemSelected;

    #endregion

    #region Fields

    private readonly ReportBand _band;
    private bool _isSelected;

    #endregion

    #region Constructor

    public ReportBandViewModel(ReportBand band)
      : base(band.SubBands)
    {
      _band = band;
      Items = new ObservableCollection<IItemViewModel>();

      foreach (var item in band.Items)
      {
        var itemVM = ViewModelFactory.CreateItemViewModel(item, this);
        Items.Add(itemVM);
        itemVM.PropertyChanged += ItemVM_PropertyChanged;
      }

      band.ItemAdded += Band_ItemAdded;
      band.ItemRemoved += Band_ItemRemoved;

      SelectCommand = new ActionCommand(Select);
      EditDetailsCommand = new ActionCommand(EditDetails, CanEditDetails);
    }

    #endregion

    #region Properties

    public Guid ID => _band.ID;

    internal ReportBand Band => _band;

    public double Height
    {
      get => _band.Height;
      set => _band.Height = value;
    }

    public string DataSource
    {
      get => _band.DataSource;
      set
      {
        _band.DataSource = value;
        OnPropertyChanged(nameof(FullDataSource));
        OnPropertyChanged();
      }
    }

    public string FullDataSource => Parent is ReportBandViewModel reportBandViewModel ? reportBandViewModel.FullDataSource + "." + DataSource : DataSource;


    public bool IsSelected
    {
      get => _isSelected;
      set
      {
        if (_isSelected != value)
        {
          _isSelected = value;
          if (_isSelected)
          {
            SelectBand();
          }

          OnSelectionChanged();
          OnPropertyChanged();
        }
      }
    }

    public IBandParentViewModel Parent { get; internal set; }

    public ReportViewModel ReportVM
    {
      get
      {
        return Parent switch
        {
          ReportViewModel reportVM => reportVM,
          ReportBandViewModel rbVM => rbVM.ReportVM,
          _ => null,
        };
      }
    }

    public ObservableCollection<IItemViewModel> Items { get; }

    #endregion

    #region Commands

    #region Select

    public ICommand SelectCommand { get; }

    public void Select()
    {
      IsSelected = true;
    }

    #endregion

    #region Edit Details

    public ICommand EditDetailsCommand { get; }

    public void EditDetails()
    {
      string oldDataSource = DataSource;
      var v = ViewFactory.Instance.CreateView(this);
      if (v.ShowDialog() != true)
      {
        DataSource = oldDataSource;
      }
      else if (ReportVM != null)
      {
        ReportVM.IsDirty = true;
      }
    }

    private bool CanEditDetails()
    {
      return IsSelected;
    }

    #endregion

    #endregion

    #region Public Methods

    public IItemViewModel AddTextItem()
    {
      _band.AddTextItem();
      Debug.Assert(Items.Last() is TextItemViewModel);
      return Items.Last();
    }

    public void RemoveItem(IItemViewModel itemVM)
    {
      _band.RemoveItem(itemVM?.Item);
    }

    #endregion

    #region Event Handlers

    private void ItemVM_PropertyChanged(object sender, PropertyChangedEventArgs e)
    {
      if (e.PropertyName == nameof(IItemViewModel.IsSelected))
      {
        SelectItem(sender as IItemViewModel);
        ItemSelected?.Invoke(sender, EventArgs.Empty);
      }
      else
      {
        ReportVM.IsDirty = true;
      }
    }

    private void Band_ItemAdded(object sender, ItemsEventArgs e)
    {
      var itemVM = ViewModelFactory.CreateItemViewModel(e.Item, this);
      Items.Add(itemVM);
      itemVM.IsSelected = true;
      itemVM.PropertyChanged += ItemVM_PropertyChanged;
      ReportVM.IsDirty = true;
    }

    private void Band_ItemRemoved(object sender, ItemsEventArgs e)
    {
      foreach (var itemVM in Items.ToList())
      {
        if (itemVM.Item == e.Item)
        {
          Items.Remove(itemVM);
          itemVM.PropertyChanged -= ItemVM_PropertyChanged;
          ReportVM.IsDirty = true;
        }
      }
    }

    #endregion

    #region Private Methods

    private void SelectItem(IItemViewModel itemVM)
    {
      IsSelected = true;
      SelectItem(ReportVM, itemVM);
    }

    private static void SelectItem(IBandParentViewModel parentVM, IItemViewModel itemVM)
    {
      if (parentVM != null)
      {
        foreach (var childBand in parentVM.Bands)
        {
          foreach (var item in childBand.Items)
          {
            item.IsSelected = item == itemVM;
          }

          SelectItem(childBand, itemVM);
        }
      }
    }

    /// <summary>
    /// Selects the current band. Deselects all others, beginning at the report.
    /// </summary>
    private void SelectBand()
    {
      var parent = Parent;
      while (parent is ReportBandViewModel reportBandViewModel)
      {
        parent = reportBandViewModel.Parent;
      }

      Debug.Assert(parent is ReportViewModel);
      SelectBand(parent, this);
    }

    /// <summary>
    /// Selects the given band. Deselects all children.
    /// </summary>
    private static void SelectBand(IBandParentViewModel parentVM, ReportBandViewModel reportBandVM)
    {
      if (parentVM != null)
      {
        foreach (var childBand in parentVM.Bands)
        {
          childBand.IsSelected = childBand == reportBandVM;
          SelectBand(childBand, reportBandVM);
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      base.Dispose(disposing);

      if (disposing)
      {
        _band.ItemAdded -= Band_ItemAdded;
        _band.ItemRemoved -= Band_ItemRemoved;

        foreach (var itemVM in Items)
        {
          itemVM.PropertyChanged -= ItemVM_PropertyChanged;
          itemVM.Dispose();
        }
      }
    }

    #endregion
  }
}
