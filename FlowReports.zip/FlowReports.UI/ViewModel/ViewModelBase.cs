﻿namespace FlowReports.UI.ViewModel
{
  public abstract class ViewModelBase : ES.Tools.Core.MVVM.ViewModel
  {
  }
}