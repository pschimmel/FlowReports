﻿using FlowReports.Model.ReportItems;

namespace FlowReports.UI.ViewModel
{
  internal class TextItemViewModel : EditorItemViewModel<TextItem>
  {
    public TextItemViewModel(TextItem item, ReportBandViewModel bandVM)
      : base(item, bandVM)
    { }

    public string Text
    {
      get => _item.Text;
      set
      {
        if (_item.Text != value)
        {
          _item.Text = value;
          OnPropertyChanged();
        }
      }
    }
  }
}
